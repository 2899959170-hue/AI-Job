# 大厂运营岗SQL笔试真题库

> 来源：字节跳动、阿里巴巴、腾讯、美团、滴滴等大厂运营/数据分析岗笔试题（2022-2024年）

---

## 第一章：基础题（⭐）

### 题目 B-01：查找高价值用户
**出处**：美团运营实习笔试  
**表结构**：
```
orders(order_id, user_id, amount, create_time, status)
```
**题目**：找出2024年1月，下单金额超过1000元且订单状态为"已完成"的用户ID和总消费金额，按总消费金额降序排列。

**解题思路**：
1. 过滤条件：时间范围 + 状态筛选
2. 按用户分组，求和
3. HAVING过滤金额
4. 排序

**答案**：
```sql
SELECT 
    user_id,
    SUM(amount) as total_amount
FROM orders
WHERE create_time >= '2024-01-01' 
    AND create_time < '2024-02-01'
    AND status = '已完成'
GROUP BY user_id
HAVING SUM(amount) > 1000
ORDER BY total_amount DESC;
```

**易错点**：WHERE里不能用聚合函数结果，必须用HAVING。

---

### 题目 B-02：商品分类统计
**出处**：阿里运营笔试  
**表结构**：
```
products(product_id, name, category, price, stock)
```
**题目**：统计每个品类的商品数量、平均价格（保留2位小数）和库存总量，只显示商品数量>10的品类。

**答案**：
```sql
SELECT 
    category,
    COUNT(*) as product_cnt,
    ROUND(AVG(price), 2) as avg_price,
    SUM(stock) as total_stock
FROM products
GROUP BY category
HAVING COUNT(*) > 10
ORDER BY product_cnt DESC;
```

---

## 第二章：JOIN与子查询（⭐⭐）

### 题目 J-01：用户订单详情关联
**出处**：滴滴运营笔试  
**表结构**：
```
users(user_id, name, register_date, city)
trips(trip_id, user_id, driver_id, start_time, end_time, amount, status)
```
**题目**：找出注册时间超过180天但从未下单的用户（截止今天），显示用户ID、姓名、注册日期、注册城市。

**解题思路**：注册了但没有行程记录 → LEFT JOIN + NULL过滤，或者NOT IN/NOT EXISTS

**答案**（三种写法，推荐LEFT JOIN）：
```sql
-- 写法1：LEFT JOIN（推荐，性能最好）
SELECT u.user_id, u.name, u.register_date, u.city
FROM users u
LEFT JOIN trips t ON u.user_id = t.user_id
WHERE t.user_id IS NULL
    AND DATEDIFF(CURDATE(), u.register_date) > 180;

-- 写法2：NOT EXISTS
SELECT user_id, name, register_date, city
FROM users u
WHERE NOT EXISTS (
    SELECT 1 FROM trips t WHERE t.user_id = u.user_id
)
AND DATEDIFF(CURDATE(), register_date) > 180;
```

**易错点**：LEFT JOIN后要判断右表的字段IS NULL，不是判断左表。

---

### 题目 J-02：Top-N问题（每类取前3）
**出处**：腾讯运营笔试  
**表结构**：
```
content(content_id, category, author_id, views, publish_date)
```
**题目**：找出每个内容类别中播放量最高的前3个内容，显示类别、内容ID、播放量、名次。

**解题思路**：这是经典Top-N问题，必须用窗口函数ROW_NUMBER()

**答案**：
```sql
SELECT category, content_id, views, rn
FROM (
    SELECT 
        category,
        content_id,
        views,
        ROW_NUMBER() OVER (PARTITION BY category ORDER BY views DESC) as rn
    FROM content
) t
WHERE rn <= 3
ORDER BY category, rn;
```

**易错点**：ROW_NUMBER()不能直接用在WHERE里，必须套一层子查询。

---

### 题目 J-03：自连接找关系
**出处**：腾讯社交产品笔试  
**表结构**：
```
follows(follower_id, following_id, follow_date)
```
**题目**：找出互相关注的用户对（A关注B且B关注A），每对只显示一次（user_id小的在前）。

**答案**：
```sql
SELECT 
    LEAST(a.follower_id, a.following_id) as user1,
    GREATEST(a.follower_id, a.following_id) as user2
FROM follows a
INNER JOIN follows b 
    ON a.follower_id = b.following_id 
    AND a.following_id = b.follower_id
WHERE a.follower_id < a.following_id;
```

---

## 第三章：窗口函数（⭐⭐⭐）大厂必考

### 题目 W-01：用户连续登录天数
**出处**：字节跳动运营笔试（原题！）  
**表结构**：
```
login_log(user_id, login_date)  -- login_date每天每个用户只有一条记录
```
**题目**：找出连续登录天数≥3天的用户，输出用户ID、连续登录开始日期、结束日期、连续天数。

**解题思路**（分3步）：
1. 用ROW_NUMBER()给每个用户的登录日期编号
2. 用日期减去编号，相同结果说明是连续的（经典技巧！）
3. 按用户和"差值"分组，统计每组的天数和起止日期

**答案**：
```sql
WITH ranked AS (
    SELECT 
        user_id,
        login_date,
        ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY login_date) as rn,
        DATE_SUB(login_date, INTERVAL ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY login_date) DAY) as grp_key
    FROM login_log
),
grouped AS (
    SELECT 
        user_id,
        MIN(login_date) as start_date,
        MAX(login_date) as end_date,
        COUNT(*) as consecutive_days
    FROM ranked
    GROUP BY user_id, grp_key
)
SELECT user_id, start_date, end_date, consecutive_days
FROM grouped
WHERE consecutive_days >= 3
ORDER BY user_id, start_date;
```

**为什么日期减编号就能判断连续？**  
连续日期：2024-01-01(rn=1), 2024-01-02(rn=2), 2024-01-03(rn=3)  
差值：2023-12-31, 2023-12-31, 2023-12-31 → 相同！  
中断后：2024-01-05(rn=4) → 差值：2024-01-01 → 不同！

---

### 题目 W-02：月环比增长率
**出处**：阿里电商运营笔试  
**表结构**：
```
orders(order_id, user_id, amount, category, create_date)
```
**题目**：计算2024年每个月的GMV及月环比增长率（保留2位小数），如果上月无数据则增长率显示NULL。

**答案**：
```sql
WITH monthly_gmv AS (
    SELECT 
        DATE_FORMAT(create_date, '%Y-%m') as month,
        SUM(amount) as gmv
    FROM orders
    WHERE YEAR(create_date) = 2024
    GROUP BY DATE_FORMAT(create_date, '%Y-%m')
)
SELECT 
    month,
    gmv,
    LAG(gmv) OVER (ORDER BY month) as last_month_gmv,
    ROUND(
        (gmv - LAG(gmv) OVER (ORDER BY month)) / LAG(gmv) OVER (ORDER BY month) * 100, 
        2
    ) as mom_growth_pct
FROM monthly_gmv
ORDER BY month;
```

---

### 题目 W-03：用户首购分析
**出处**：美团运营笔试  
**表结构**：
```
orders(order_id, user_id, amount, create_time, product_category)
```
**题目**：找出每个用户的首次下单日期、首次购买的品类和金额。

**答案**：
```sql
SELECT user_id, create_time as first_order_time, product_category, amount
FROM (
    SELECT 
        user_id,
        create_time,
        product_category,
        amount,
        ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY create_time ASC) as rn
    FROM orders
) t
WHERE rn = 1;
```

**考点**：RANK() vs ROW_NUMBER()的区别
- ROW_NUMBER()：同时下单只取一条（适合本题）
- RANK()：同时下单都显示，名次相同

---

## 第四章：运营专题压轴题（⭐⭐⭐⭐）

### 题目 O-01：用户次日/7日/30日留存率
**出处**：字节跳动运营笔试（最高频真题！）  
**表结构**：
```
register_log(user_id, register_date)
active_log(user_id, active_date)
```
**题目**：计算2024年1月每天注册用户的次日、7日、30日留存率。

**解题思路**：
1. 以注册日为基准，LEFT JOIN活跃日志
2. 用DATEDIFF判断是第1/7/30天是否活跃
3. 用CASE WHEN + COUNT DISTINCT统计

**答案**：
```sql
SELECT 
    r.register_date,
    COUNT(DISTINCT r.user_id) as register_cnt,
    -- 次日留存
    COUNT(DISTINCT CASE 
        WHEN DATEDIFF(a.active_date, r.register_date) = 1 
        THEN r.user_id END) as day1_retain_cnt,
    ROUND(COUNT(DISTINCT CASE 
        WHEN DATEDIFF(a.active_date, r.register_date) = 1 
        THEN r.user_id END) / COUNT(DISTINCT r.user_id), 4) as day1_rate,
    -- 7日留存
    COUNT(DISTINCT CASE 
        WHEN DATEDIFF(a.active_date, r.register_date) = 7 
        THEN r.user_id END) as day7_retain_cnt,
    ROUND(COUNT(DISTINCT CASE 
        WHEN DATEDIFF(a.active_date, r.register_date) = 7 
        THEN r.user_id END) / COUNT(DISTINCT r.user_id), 4) as day7_rate,
    -- 30日留存
    COUNT(DISTINCT CASE 
        WHEN DATEDIFF(a.active_date, r.register_date) = 30 
        THEN r.user_id END) as day30_retain_cnt,
    ROUND(COUNT(DISTINCT CASE 
        WHEN DATEDIFF(a.active_date, r.register_date) = 30 
        THEN r.user_id END) / COUNT(DISTINCT r.user_id), 4) as day30_rate
FROM register_log r
LEFT JOIN active_log a ON r.user_id = a.user_id
WHERE r.register_date >= '2024-01-01' AND r.register_date < '2024-02-01'
GROUP BY r.register_date
ORDER BY r.register_date;
```

**易错点汇总**：
- 必须用LEFT JOIN（不是INNER JOIN），否则当天活跃=0的日期会丢失
- 用DATEDIFF(新日期, 旧日期)，参数顺序别写反
- 分母是注册人数，分子是留存人数，注意用DISTINCT

---

### 题目 O-02：电商转化漏斗分析
**出处**：阿里/天猫运营笔试  
**表结构**：
```
funnel_log(user_id, step, event_time, dt)
-- step: 'expose'曝光 → 'click'点击 → 'add_cart'加购 → 'pay'支付
```
**题目**：计算2024-01-15的电商转化漏斗，显示每个步骤的UV、转化率（相对上一步）、整体转化率。

**答案**：
```sql
WITH step_uv AS (
    SELECT
        COUNT(DISTINCT CASE WHEN step = 'expose' THEN user_id END) as expose_uv,
        COUNT(DISTINCT CASE WHEN step = 'click' THEN user_id END) as click_uv,
        COUNT(DISTINCT CASE WHEN step = 'add_cart' THEN user_id END) as add_cart_uv,
        COUNT(DISTINCT CASE WHEN step = 'pay' THEN user_id END) as pay_uv
    FROM funnel_log
    WHERE dt = '2024-01-15'
)
SELECT 
    '曝光' as step_name, expose_uv as uv, NULL as step_cvr, NULL as total_cvr FROM step_uv
UNION ALL
SELECT '点击', click_uv, 
    ROUND(click_uv/expose_uv*100, 2),
    ROUND(click_uv/expose_uv*100, 2) FROM step_uv
UNION ALL
SELECT '加购', add_cart_uv, 
    ROUND(add_cart_uv/click_uv*100, 2),
    ROUND(add_cart_uv/expose_uv*100, 2) FROM step_uv
UNION ALL
SELECT '支付', pay_uv, 
    ROUND(pay_uv/add_cart_uv*100, 2),
    ROUND(pay_uv/expose_uv*100, 2) FROM step_uv;
```

---

### 题目 O-03：用户分层（RFM模型）
**出处**：阿里/京东运营笔试  
**表结构**：
```
orders(order_id, user_id, amount, create_date)
```
**题目**：基于最近30天的订单数据，用RFM模型对用户分层：
- R（最近购买）：最近一次购买距今天数
- F（购买频次）：购买次数
- M（消费金额）：总消费金额
根据R≤7天、F≥3次、M≥500元为高值，其余为低值，组合成用户分层标签。

**答案**：
```sql
WITH rfm AS (
    SELECT 
        user_id,
        DATEDIFF(CURDATE(), MAX(create_date)) as R,
        COUNT(DISTINCT order_id) as F,
        SUM(amount) as M
    FROM orders
    WHERE create_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY user_id
)
SELECT 
    user_id, R, F, M,
    CASE 
        WHEN R <= 7 AND F >= 3 AND M >= 500 THEN '重要价值客户'
        WHEN R <= 7 AND F >= 3 AND M < 500 THEN '重要发展客户'
        WHEN R <= 7 AND F < 3 AND M >= 500 THEN '重要保持客户'
        WHEN R <= 7 AND F < 3 AND M < 500 THEN '一般保持客户'
        WHEN R > 7 AND F >= 3 AND M >= 500 THEN '重要挽回客户'
        WHEN R > 7 AND F >= 3 AND M < 500 THEN '一般发展客户'
        WHEN R > 7 AND F < 3 AND M >= 500 THEN '重要唤回客户'
        ELSE '流失客户'
    END as user_segment
FROM rfm
ORDER BY M DESC;
```

---

### 题目 O-04：新用户7日行为分析
**出处**：美团运营笔试  
**表结构**：
```
users(user_id, register_date)
orders(order_id, user_id, amount, create_date)
```
**题目**：分析2024年1月新注册用户在注册后7天内的购买情况：有多少人下过单、平均下单次数、平均消费金额、首单平均时间（注册到首单的小时数）。

**答案**：
```sql
WITH new_users AS (
    SELECT user_id, register_date 
    FROM users 
    WHERE register_date >= '2024-01-01' AND register_date < '2024-02-01'
),
user_7day_orders AS (
    SELECT 
        n.user_id,
        n.register_date,
        COUNT(o.order_id) as order_cnt,
        SUM(o.amount) as total_amount,
        MIN(o.create_date) as first_order_date
    FROM new_users n
    LEFT JOIN orders o 
        ON n.user_id = o.user_id 
        AND DATEDIFF(o.create_date, n.register_date) BETWEEN 0 AND 6
    GROUP BY n.user_id, n.register_date
)
SELECT 
    COUNT(user_id) as total_new_users,
    COUNT(CASE WHEN order_cnt > 0 THEN user_id END) as purchasers,
    ROUND(COUNT(CASE WHEN order_cnt > 0 THEN user_id END) / COUNT(user_id) * 100, 2) as purchase_rate_pct,
    ROUND(AVG(CASE WHEN order_cnt > 0 THEN order_cnt END), 2) as avg_order_cnt,
    ROUND(AVG(CASE WHEN order_cnt > 0 THEN total_amount END), 2) as avg_amount,
    ROUND(AVG(CASE WHEN first_order_date IS NOT NULL 
        THEN TIMESTAMPDIFF(HOUR, register_date, first_order_date) END), 1) as avg_hours_to_first_order
FROM user_7day_orders;
```

---

## 常考知识点速记

### 时间函数
```sql
CURDATE()              -- 今天日期
NOW()                  -- 当前时间
DATEDIFF(d1, d2)       -- d1-d2的天数差
DATE_SUB(date, INTERVAL 7 DAY)  -- 7天前
DATE_FORMAT(date, '%Y-%m')      -- 格式化为年月
YEAR(date), MONTH(date), DAY(date)
TIMESTAMPDIFF(HOUR, t1, t2)    -- 小时差
```

### 窗口函数（大厂必考）
```sql
ROW_NUMBER() OVER (PARTITION BY col ORDER BY col)   -- 不并列，连续
RANK() OVER (PARTITION BY col ORDER BY col)          -- 并列，跳号
DENSE_RANK() OVER (PARTITION BY col ORDER BY col)   -- 并列，不跳号
LAG(col, 1) OVER (ORDER BY col)                     -- 上一行的值
LEAD(col, 1) OVER (ORDER BY col)                    -- 下一行的值
SUM(col) OVER (PARTITION BY col ORDER BY col)       -- 累计求和
```

### WITH语句（CTE，复杂题必用）
```sql
WITH cte1 AS (SELECT ...),
     cte2 AS (SELECT ... FROM cte1)
SELECT * FROM cte2;
```
