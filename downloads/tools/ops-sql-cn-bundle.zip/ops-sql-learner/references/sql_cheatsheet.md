# SQL速查表：运营实习笔试版

## 基础语句结构

```sql
SELECT  列名/表达式/聚合函数    -- 第5步执行
FROM    表名                    -- 第1步
JOIN    另一张表 ON 条件        -- 第2步
WHERE   行过滤条件              -- 第3步
GROUP BY 分组列                 -- 第4步
HAVING  聚合结果过滤            -- 第4.5步
ORDER BY 排序列 ASC/DESC       -- 第6步
LIMIT   行数                   -- 第7步
```

> 记住执行顺序：FROM → JOIN → WHERE → GROUP BY → HAVING → SELECT → ORDER BY → LIMIT

---

## 聚合函数

| 函数 | 作用 | 注意 |
|------|------|------|
| COUNT(*) | 总行数 | 包含NULL |
| COUNT(col) | 非NULL的行数 | 排除NULL |
| COUNT(DISTINCT col) | 去重计数 | 最常用！ |
| SUM(col) | 求和 | NULL会被忽略 |
| AVG(col) | 平均值 | NULL不参与计算 |
| MAX/MIN(col) | 最大/最小 | 可用于日期 |

---

## CASE WHEN（运营分析必备）

```sql
-- 方式1：条件式
CASE WHEN score >= 90 THEN 'A'
     WHEN score >= 70 THEN 'B'
     ELSE 'C'
END as grade

-- 方式2：等值式
CASE status
    WHEN 1 THEN '活跃'
    WHEN 0 THEN '沉默'
    ELSE '未知'
END as status_name

-- 搭配聚合函数（超常用！）
COUNT(CASE WHEN gender = 'F' THEN user_id END) as female_cnt
SUM(CASE WHEN type = 'A' THEN amount ELSE 0 END) as type_a_amount
```

---

## JOIN类型选择

```
INNER JOIN → 只要两表都有匹配的行
LEFT JOIN  → 以左表为主，右表没有就NULL（最常用）

什么时候用LEFT JOIN：
- "找出没有X记录的用户" → LEFT JOIN + WHERE 右表.id IS NULL
- "统计每个用户的订单数（包括0单用户）" → LEFT JOIN + COALESCE(count, 0)
- "用户基本信息 + 可能有的扩展信息" → LEFT JOIN
```

---

## 窗口函数速查

```sql
-- 分组排名（取Top N必用）
ROW_NUMBER() OVER (PARTITION BY category ORDER BY sales DESC)
RANK()       OVER (PARTITION BY category ORDER BY sales DESC)
DENSE_RANK() OVER (PARTITION BY category ORDER BY sales DESC)

-- 环比/同比（LAG/LEAD）
LAG(amount, 1, 0) OVER (ORDER BY month)   -- 上一行，默认值0
LEAD(amount, 1) OVER (ORDER BY month)     -- 下一行

-- 累计/滑动计算
SUM(amount) OVER (PARTITION BY user_id ORDER BY date)  -- 累计求和
AVG(amount) OVER (ORDER BY date ROWS 6 PRECEDING)      -- 最近7天均值

-- 首尾值
FIRST_VALUE(col) OVER (PARTITION BY col ORDER BY col)
LAST_VALUE(col)  OVER (PARTITION BY col ORDER BY col)
```

---

## 时间函数（大厂必考）

```sql
-- 获取当前时间
CURDATE()           -- 2024-01-15（日期）
NOW()               -- 2024-01-15 10:30:00（日期时间）

-- 计算时间差
DATEDIFF('2024-01-10', '2024-01-01')         -- 返回9（天）
TIMESTAMPDIFF(HOUR, '2024-01-01', '2024-01-02')   -- 返回24（小时）

-- 日期加减
DATE_ADD(date, INTERVAL 7 DAY)
DATE_SUB(date, INTERVAL 1 MONTH)
date + INTERVAL 1 DAY   -- 简写

-- 格式化
DATE_FORMAT(date, '%Y-%m')      -- 2024-01（常用于按月聚合）
DATE_FORMAT(date, '%Y-%m-%d')   -- 2024-01-15
DATE_FORMAT(date, '%Y%u')       -- 按周（202403）

-- 提取部分
YEAR(date)   MONTH(date)   DAY(date)
HOUR(time)   MINUTE(time)
WEEKDAY(date)    -- 0=周一，6=周日
DAYOFWEEK(date)  -- 1=周日，7=周六（MySQL）
```

---

## WITH语句（让复杂SQL更清晰）

```sql
WITH 
step1 AS (
    -- 第一步：清洗数据或基础聚合
    SELECT user_id, SUM(amount) as total
    FROM orders
    GROUP BY user_id
),
step2 AS (
    -- 第二步：基于step1继续处理
    SELECT *, NTILE(4) OVER (ORDER BY total DESC) as quartile
    FROM step1
)
-- 最终查询
SELECT * FROM step2 WHERE quartile = 1;
```

---

## 常用模板

### 留存率模板
```sql
SELECT 
    r.cohort_date,
    COUNT(DISTINCT r.user_id) as cohort_size,
    COUNT(DISTINCT CASE WHEN DATEDIFF(a.active_date, r.cohort_date) = 1 THEN r.user_id END) as d1,
    COUNT(DISTINCT CASE WHEN DATEDIFF(a.active_date, r.cohort_date) = 7 THEN r.user_id END) as d7
FROM register_log r
LEFT JOIN active_log a ON r.user_id = a.user_id
GROUP BY r.cohort_date;
```

### Top-N模板
```sql
SELECT * FROM (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY group_col ORDER BY rank_col DESC) as rn
    FROM table_name
) t WHERE rn <= N;
```

### 连续登录模板
```sql
WITH t AS (
    SELECT user_id, login_date,
        DATE_SUB(login_date, INTERVAL ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY login_date) DAY) as grp
    FROM login_log
)
SELECT user_id, MIN(login_date) as start, MAX(login_date) as end, COUNT(*) as days
FROM t GROUP BY user_id, grp HAVING COUNT(*) >= 3;
```

### 环比模板
```sql
SELECT month, gmv,
    LAG(gmv) OVER (ORDER BY month) as last_month,
    ROUND((gmv - LAG(gmv) OVER (ORDER BY month)) / LAG(gmv) OVER (ORDER BY month) * 100, 2) as mom_pct
FROM monthly_summary;
```

### 漏斗分析模板
```sql
SELECT 
    COUNT(DISTINCT CASE WHEN step = 'expose' THEN user_id END) as s1,
    COUNT(DISTINCT CASE WHEN step = 'click'  THEN user_id END) as s2,
    COUNT(DISTINCT CASE WHEN step = 'pay'    THEN user_id END) as s3
FROM funnel_log WHERE dt = '2024-01-01';
```
