# SQL系统化学习路径：运营实习笔试专项

## 快速定级测试

在开始之前，先判断你在哪个阶段：

**问题1**：能写出"查询每个城市的用户数"的SQL吗？
- 不能 → 从阶段1开始
- 能 → 继续问题2

**问题2**：能写出"查询下过单的用户姓名和订单总金额"的SQL吗？（需要JOIN两张表）
- 不能 → 从阶段2后半段开始
- 能 → 继续问题3

**问题3**：能写出"每个用户最近一次下单的金额"的SQL吗？（不用子查询）
- 不能 → 从阶段3开始（窗口函数）
- 能 → 直接到阶段4运营专题练习

---

## 阶段1：基础查询（1-2天）

### 知识点清单

1. **SELECT基础**
   - 选列、别名、去重DISTINCT
   - 字符串函数：CONCAT、LENGTH、SUBSTRING、TRIM
   - 数值函数：ROUND、CEIL、FLOOR、ABS

2. **WHERE条件**
   - 比较运算：=, !=, >, <, >=, <=
   - 范围：BETWEEN...AND
   - 集合：IN, NOT IN
   - 模糊：LIKE（%代表任意字符）
   - 空值：IS NULL, IS NOT NULL
   - 组合：AND, OR, NOT

3. **排序与限制**
   - ORDER BY（ASC升序，DESC降序）
   - LIMIT n / LIMIT offset, n

### 运营场景练习

**练习1.1**：从用户表中找出注册城市为北京或上海，且手机号不为空的用户，按注册时间降序显示前100条。

```sql
SELECT user_id, name, city, phone, register_date
FROM users
WHERE city IN ('北京', '上海')
    AND phone IS NOT NULL
ORDER BY register_date DESC
LIMIT 100;
```

**练习1.2**：找出商品名称包含"套餐"字样、价格在50-200元之间的商品。

```sql
SELECT product_id, name, price, category
FROM products
WHERE name LIKE '%套餐%'
    AND price BETWEEN 50 AND 200;
```

---

## 阶段2：聚合分析（2-3天）

### 知识点清单

1. **聚合函数**
   - COUNT(*)、COUNT(col)、COUNT(DISTINCT col)
   - SUM、AVG、MAX、MIN

2. **GROUP BY**
   - 按单列/多列分组
   - SELECT里只能有GROUP BY的列和聚合函数

3. **HAVING**
   - WHERE是过滤原始行
   - HAVING是过滤聚合后的结果

4. **CASE WHEN（超重要）**
   ```sql
   CASE WHEN condition1 THEN result1
        WHEN condition2 THEN result2
        ELSE result3
   END
   ```

### 运营场景练习

**练习2.1**：统计每个渠道（channel）的注册用户数、活跃用户数、活跃率。

```sql
SELECT 
    channel,
    COUNT(*) as register_cnt,
    COUNT(CASE WHEN is_active = 1 THEN user_id END) as active_cnt,
    ROUND(COUNT(CASE WHEN is_active = 1 THEN user_id END) / COUNT(*) * 100, 2) as active_rate
FROM users
GROUP BY channel
ORDER BY active_rate DESC;
```

**练习2.2**：将用户按消费金额分层（0元、1-100元、100-500元、500元以上），统计每层人数。

```sql
SELECT 
    CASE 
        WHEN total_amount = 0 THEN '0元（未消费）'
        WHEN total_amount < 100 THEN '1-99元'
        WHEN total_amount < 500 THEN '100-499元'
        ELSE '500元以上'
    END as amount_segment,
    COUNT(*) as user_cnt
FROM (
    SELECT user_id, COALESCE(SUM(amount), 0) as total_amount
    FROM users
    LEFT JOIN orders USING(user_id)
    GROUP BY user_id
) t
GROUP BY amount_segment;
```

---

## 阶段3：多表关联（3-4天）

### 知识点清单

1. **JOIN类型**
   - INNER JOIN：两表都有才出现
   - LEFT JOIN：左表全部出现，右表没有显示NULL
   - RIGHT JOIN：右表全部出现（实际用LEFT JOIN更多）
   
2. **子查询**
   - WHERE中的子查询：`WHERE col IN (SELECT...)`
   - FROM中的子查询（派生表）
   - EXISTS / NOT EXISTS

3. **WITH语句（CTE）**
   - 让复杂查询更清晰
   - 可以定义多个，互相引用

### 理解LEFT JOIN的关键

```
users表：用户A、用户B、用户C
orders表：用户A有订单、用户B有订单（用户C没有订单）

LEFT JOIN结果：
用户A  订单数据
用户B  订单数据  
用户C  NULL NULL NULL   ← 右表字段全是NULL

所以找"没有下过单的用户"：
WHERE orders.user_id IS NULL
```

---

## 阶段4：窗口函数（4-5天）

### 为什么这么重要？

字节、阿里、腾讯、美团的笔试几乎100%考窗口函数，而且普通GROUP BY无法完成这些任务：
- "每类商品中价格最高的3个"
- "用户的第几次购买"
- "连续登录天数"
- "与上月相比增长了多少"

### 窗口函数语法

```sql
函数名() OVER (
    PARTITION BY 分组列    -- 类似GROUP BY，但不合并行
    ORDER BY 排序列
    ROWS/RANGE 范围定义   -- 可选，定义计算范围
)
```

### 四大类窗口函数

**排名类**
```sql
ROW_NUMBER()  -- 1,2,3,4（唯一，无并列）
RANK()        -- 1,1,3,4（并列，跳号）
DENSE_RANK()  -- 1,1,2,3（并列，不跳）
```

**偏移类**（环比必用）
```sql
LAG(col, n)   -- 向前n行的值（上一期）
LEAD(col, n)  -- 向后n行的值（下一期）
```

**聚合类**（累计计算）
```sql
SUM(amount) OVER (PARTITION BY user_id ORDER BY date) -- 每个用户的累计消费
AVG(score) OVER (PARTITION BY dept)                   -- 部门平均（每行保留）
```

### 核心差异：GROUP BY vs 窗口函数

```sql
-- GROUP BY：每组只有1行
SELECT user_id, SUM(amount) FROM orders GROUP BY user_id;
-- 结果：用户A 500 | 用户B 300

-- 窗口函数：每行都保留，新增计算列
SELECT user_id, order_id, amount,
    SUM(amount) OVER (PARTITION BY user_id ORDER BY create_date) as cumulative
FROM orders;
-- 结果：用户A 订单1 100 100 | 用户A 订单2 200 300 | 用户B ...
```

---

## 阶段5：运营专题（持续练习）

### 五大核心运营场景

1. **留存分析** → 参考真题 O-01
2. **漏斗分析** → 参考真题 O-02
3. **用户分层** → 参考真题 O-03
4. **新用户分析** → 参考真题 O-04
5. **连续行为** → 参考真题 W-01

### 备考策略

| 剩余时间 | 建议重点 |
|---------|---------|
| 1个月以上 | 完整走完5个阶段 |
| 2-3周 | 快速过完阶段1-2，重点搞定阶段3-4，刷完所有真题 |
| 1周 | 直接背熟留存/漏斗/连续登录三大模板，刷高频题 |
| 3天 | 把exam_questions.md的所有答案理解并能默写 |

### 每日练习建议

- 每天做2-3道题，不要贪多
- 遇到不会的先自己想10分钟
- 写完后想"这道题如果数据量很大，性能有问题吗？"
- 主动找运营/业务场景：想想工作中的数据问题怎么用SQL解

---

## 笔试注意事项

1. **时间管理**：SQL题一般2-4道，每题控制在10-15分钟
2. **先想后写**：用中文写出计算步骤再写SQL，减少错误
3. **拿分策略**：写不出完整SQL，写出SELECT和GROUP BY的框架也能得部分分
4. **注释**：可以写注释说明你的思路，展示业务理解
5. **常见扣分点**：
   - 忘记加DISTINCT
   - JOIN类型选错（用INNER失去NULL值）
   - DATEDIFF参数顺序写反
   - GROUP BY里漏掉SELECT的非聚合列
